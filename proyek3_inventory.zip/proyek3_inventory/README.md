# Aplikasi Sistem Iventory<br/>
## Free Source Code<br/>

tools aplikasi sistem inventory
- Codeigniter 3
- Bootstrap 4
- SB Admin 2 Template
- Datatables
- Chart.js

### Keterangan <br/>
Database : <code>proyek3_inventory</code><br/>
<br/>
