<?php
class Model_Barang extends CI_Model
{
	public function getDatabarang($id_barang = null)
	{
		if ($id_barang === null) {
			$semua_data_barang = $this->db->get("barang")->result();
			return $semua_data_barang;
		} else {
			$data_barang_byid_barang = $this->db->get_where('barang', ['id_barang' => $id_barang])->result();
			return $data_barang_byid_barang;
		}
	}
}
?>