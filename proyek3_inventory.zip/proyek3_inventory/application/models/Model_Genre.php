<!-- Updated by Rizaluardi-PC -->
<?php

//extends class Model
/**
 * 
 */
class Model_Genre extends CI_Model
{
	
	public function getDataGenre($id_genre = null)
	{
		if ($id_genre === null) {
			$semua_data_genre = $this->db->get("genre")->result();
			return $semua_data_genre;
		} else {
			$data_genre_byid_genre = $this->db->get_where('genre', ['id_genre' => $id_genre])->result();
			return $data_genre_byId_genre;
		}
	}
	//fungsi tambah data
	public function tambahGenre($data){
		//menggunakan query builder
		$this->db->insert('genre', $data);
		return $this->db->affected_rows();
	}
	//fungsi hapus data
	public function hapusGenre($id_genre){
		//menggunakan query builder
		$this->db->delete('genre', ['id_genre' => $id_genre]);
		return $this->db->affected_rows();
	}
	//fungsi update data mahasiswa
	public function ubahGenre($data, $id_genre){
		//menggunakan query builder
		$this->db->update('genre', $data, ['id_genre' => $id_genre]);
		return $this->db->affected_rows();
	}
	
}
?>