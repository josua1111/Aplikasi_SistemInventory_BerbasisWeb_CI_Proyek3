<?php

require APPPATH.'/libraries/REST_Controller.php';
/**
 * 
 */
class Getbarang extends REST_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_Barang', 'brg');
	}
	//fungsi CRUD (GET,POST,PUT,DELETE) simpan di bawah fungsi constructor

	public function index_get(){
		$id_barang = $this->get('id_barang');
		if ($id_barang === null) {
			$data_barang = $this->brg->getDatabarang();
		} else {
			$data_barang = $this->brg->getDatabarang($id_barang);
		}
		if ($data_barang) {
			$this->response(
				[
					'status' => true,
					'data_person' => $data_barang
						
				],
				REST_Controller::HTTP_OK
			);
		} else {
			$this->response(
				[
					'status' => false,
					'data_person' => "Data Tidak Ditemukan 404"
						
				],
				REST_Controller::HTTP_NOT_FOUND
			);
		}
	}
}
?>