<!-- Updated by Rizaluardi-PC -->
<?php

require APPPATH.'/libraries/REST_Controller.php';
/**
 * 
 */
class Genre extends REST_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_Genre', 'gnr');
	}
	//fungsi CRUD (GET,POST,PUT,DELETE) simpan di bawah fungsi constructor
	public function index_get(){
		$id_genre = $this->get('id_genre');
		if ($id_genre === null) {
			$data_genre = $this->gnr->getDataGenre();
		} else {
			$data_genre = $this->gnr->getDataGenre($id_genre);
		}
		if ($data_genre) {
			$this->response(
				[
					'status' => true,
					'data_person' => $data_genre
						
				],
				REST_Controller::HTTP_OK
			);
		} else {
			$this->response(
				[
					'status' => false,
					'data_person' => "Data Tidak Ditemukan 404"
						
				],
				REST_Controller::HTTP_NOT_FOUND
			);
		}
	}

	public function index_post(){
		$id_genre = $this->post('id_genre');
		$genre = $this->post('genre');

		$data = [
			'id_genre' => $id_genre,
			'genre' => $genre
		];
		if ($id_genre === null || $genre === null) {
			//return $this->empty_response();
			$this->response(
				[
					'status' => false,
					'message' => 'data yang dikirimkan tidak boleh kosong'
				],
				REST_Controller::HTTP_BAD_REQUEST
			);
		} else {
			//jika data tersimpan
			if ($this->gnr->tambahGenre($data) > 0) {
				$this->response(
					[
						'status' => true,
						'message' => 'data berhasil ditambahkan'
					],
					REST_Controller::HTTP_CREATED
				);
			} else {
				$this->response(
					[
						'status' => false,
						'message' => 'Gagal menambahkan data'
					],
					REST_Controller::HTTP_BAD_REQUEST
				);
			}
		}
	}
	//fungsi delete
	public function index_delete(){
		$id_genre = $this->delete('id_genre');
		if ($id_genre === null) {
			$this->response(
				[
					'status' => false,
					'message' => 'id_genre tidak boleh kosong'
				],
				REST_Controller::HTTP_BAD_REQUEST
			);
		} else {
			if ($this->gnr->hapusGenre($id_genre) > 0){
				//kondisi ketika OK
				$this->response(
					[
						'status' => true,
						'message' => 'data genre dengan id_genre : ' . $id_genre . ' berhasil dihapus'
					],
					REST_Controller::HTTP_OK
				);
			} else {
				$this->response(
					[
						'status' => false,
						'message' => 'data genre dengan id_genre : ' . $id_genre . ' tidak ditemukan'
					],
					REST_Controller::HTTP_BAD_REQUEST
				);
			}
		}
	}

	//fungsi update
	public function index_put(){
		$id_genre = $this->put('id_genre');
		$datagnr = [
			'genre' => $this->put('genre')
		];
		if ($id_genre === null) {
			$this->response(
				[
					'status' => false,
					'message' => 'id_genre tidak boleh kosong bro'
				],
				REST_Controller::HTTP_BAD_REQUEST
			);
		} else {
			//jika data tersimpan
			if($this->gnr->ubahGenre($datagnr, $id_genre) > 0){
				$this->response(
					[
						'status' => true,
						'message' => 'data genre dengan id_genre : ' .$id_genre. ' berhasil diupdate'
					],
					REST_Controller::HTTP_CREATED
				);
			} else {
				$this->response(
				[
					'status' => false,
					'message' => 'data tidak ada yg di update'
				],
				REST_Controller::HTTP_BAD_REQUEST
				);
			}
		}
	}
}
?>