<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Packaging extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Packaging";
        $data['packaging'] = $this->admin->get('packaging');
        $this->template->load('templates/dashboard', 'packaging/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_packaging', 'Nama Packaging', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Packaging";
            $this->template->load('templates/dashboard', 'packaging/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('packaging', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('packaging');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('packaging/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Packaging";
            $data['packaging'] = $this->admin->get('packaging', ['id_packaging' => $id]);
            $this->template->load('templates/dashboard', 'packaging/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('packaging', 'id_packaging', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('packaging');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('packaging/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('packaging', 'id_packaging', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('packaging');
    }
}
